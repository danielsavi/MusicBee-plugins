Place any .jpg background image files here that you want to share between different Theater Mode views.
By default, a .jpg file with the same name as the settings XML file will be loaded, but you can override this behavior by applying this to the settings file:
<settings backgroundImage="xxx.jpg" />
which will cause the plugin to load xxx.jpg in this folder as the background image


credits:
default landscape image: "Waterfront" by "~ieStudio" @ http://iestudio.deviantart.com/gallery/#/d4rxpkp
